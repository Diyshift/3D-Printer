Stealthburner printhead for Drop Effect XG hotend. 

This is a beta modified from the Phaetus Dragon printhead, as such the nozzle position is the same. Use at your own risk. 

Mounting requires 4x 3x6mm socket head cap screws. The outer heatsink/mount should be positioned so that the cutouts match that of the rear of the printhead so thhat flow is not restricted. 

